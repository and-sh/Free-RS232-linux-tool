import serial_tool.app

if __name__ == "__main__":
    serial_tool.app.main()
